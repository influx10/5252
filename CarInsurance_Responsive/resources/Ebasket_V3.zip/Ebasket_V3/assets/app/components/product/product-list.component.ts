import { Component, OnInit} from '@angular/core';
import { Router } from "@angular/router";
import { ProductService } from './product.service';
import { ErrorService } from '../../errors/error.service';
import {Product} from './product.model';
import { ProductFilter } from './product.filter';
/**
 * @component
 * @description
 * this is to show product list  for different type of products in product detail screen
 */
@Component({
    selector: 'product-list-component',
    templateUrl: './product-list.component.html'

})
export class ProductListComponent implements OnInit {

    /**
     * Constructor for ProductListComponent class
     * @param router
     * @param _productService
     * @param errorService
     */
    constructor(private router: Router,private _productService: ProductService, private errorService: ErrorService){
    }

    /**
     * @type {string}
     */
    searchString: string = '';

    /**
     *
     * @type {string}
     */
    currentProductType: string;

    /**
     *
     * @type {string}
     */
    currentCategory: string;

    /**
     *
     * @type {string}
     */
    totalItems: number = 0;

    /**
     *
     * @type {Product[]}
     */
    fruits: Product[];

    /**
     *
     * @type {Product[]}
     */
    vegetables: Product[];

    /**
     *
     * @type {Product[]}
     */
    grocery: Product[];

    /**
     * @override OnInit
     */
    ngOnInit(){
        this.getProduct();
        this.getAddedProducts();
    }

    /**
     * @description get product and set types of products
     */
    getProduct() {
       this._productService.getProduct().subscribe( (res) =>
                //TODO handle response and error here
                this.setProducts(res)
        )
    }

    /**
     * @description set  products type
     * @param res
     */
    setProducts =  function(res){
        this.fruits = res.fruits;
        this.vegetables = res.vegetables;
        this.grocery = res.grocery;
    }

    /**
     * @description handle error
     * @param error
     */
    logError = function(error) {
        this.errorService.handleError(error);
    }

    
    /**
     * @description get already added in cart
     * 
     */
    getAddedProducts = function() {
        let products: Product[];
        products= this._productService.getMyBasket();
        this.totalItems = products.length;
    }

    /**
     * @returns {Product[]|any}
     */
    getCurrentProductType =  function (): any{
        this.currentProductType = this._productService.getCurrentProductType();
        this.currentCategory = this.currentProductType.substring(0,1).toUpperCase() + this.currentProductType.substring(1) + " ";
        //TODO return category type object
        if(this.currentProductType =="fruits" ){
            return this.fruits;
        }else if(this.currentProductType =="vegetables"){
            return this.vegetables;
        }else if(this.currentProductType =="grocery"){
            return this.grocery;
        }
    }

    /**
     * @description route to basket screen
     */
    onBasketClicked = function(){
        //TODO handle basket click       
        this.router.navigate(['/', 'basket']);
    }

    /**
     * @description add product to basket
     * @param product
     */
    onAddToBasket = function(product: Product){
        //TODO  add product to basket
        product['basketCount'] = 1;        
        this._productService.addProductToBasket(product);
        this.getAddedProducts();
    }

}