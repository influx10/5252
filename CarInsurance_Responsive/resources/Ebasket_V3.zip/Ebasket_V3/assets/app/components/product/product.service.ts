import { Http, Response, Headers } from "@angular/http";
import { Injectable, EventEmitter } from "@angular/core";
import 'rxjs/Rx';
import { Observable } from "rxjs";
import {Product}  from './product.model';

/**
 * @ProductService
 * @description
 * this service to handle product
 */

@Injectable()
export class ProductService {

    /**
     * @type {string}
     */
    private productsUrl: string = 'data/products.json';

    /**
     * @type {Product[]}
     */
    public products:Product[];

    /**
     * @type {Product[]}
     */
    myBasket: Product[] = [];

    /**
     * @type {string}
     */
    _currntProductType: string = 'fruits';

    /**
     * Constructor for ProductService class
     * @param http
     */
    constructor(private http: Http) {
    }

    /**
     * @param type
     */
    setCurrentProductType(type: string ) {     
        this._currntProductType = type;
    }

    /**
     * @returns {string}
     */
    getCurrentProductType(): string {
        return this._currntProductType;
    }

    /**
     * @returns {Product[]}
     */
    public getMyBasket(): Product[]{
        return this.myBasket;
    }


    /**
     * @description add product to basket and update basket details
     * @param product
     */
    addProductToBasket(product: Product){
        //TODO add product to basket and update its details
        this.setTotalProductBasketPrice(product);       
        this.myBasket.push(product); 
    }


    /**
     * @description remove product from basket and update basket details
     * @param product
     */
    removeProductToBasket(product: Product){
        //TODO add product to basket and update its details
        for (let key in this.myBasket) {
            if(product.id=== this.myBasket[key].id){              
                this.myBasket.splice(parseInt(key), 1);
            }
        }
    }

     /**
     * @description remove all product from basket and update basket details
     * @param product
     */
    removeAllFromBasket(){
        this.myBasket = [];
    }
    /**
     *
     * @returns {number} tCount
     */
    getTotalBasketQuantity(): number {
        //TODO return total basket quantity

        let totalCount:number = 0;
        for (let key in this.myBasket) {
            totalCount += this.myBasket[key].basketCount;
        }

        return totalCount;
    }

    /**
     * @description reset basket details
     */
    resetBasket() {
        //TODO rest basket here
        this.getMyBasket();        
        this.getTotalBasketQuantity();
        this.getTotalPrice();
    }

    /**
     * @param product
     */
    setTotalProductBasketPrice(product: Product) {
        product.basketPrice = product.basketCount * product.price;
    }

    /**
     * @returns {number}
     */
    getTotalPrice(): number {
        //TODO return total price 
        let totalPrice:number = 0;
        for (let key in this.myBasket) {
            totalPrice += this.myBasket[key].basketPrice;
        }

        return totalPrice;
    }

    /**
     * @returns {Observable<Product[]>}
     */
    getProduct(): Observable <Product[]>{
        //TODO get products from productUrl
        return this.http.get('http://localhost:3000/'+this.productsUrl)
        .map(this.extractProduct)
        .catch(this.handleError);
    }

    /**
     * @param res
     * @returns {Product[]}
     */
    private extractProduct(res: Response): Product[] {
        let body = res.json();
        this.products = body.products || { };
        return this.products;
    }

    /**
     * @param error
     * @returns {ErrorObservable}
     */
    private handleError (error: any): Observable<any> {
        //TODO handle and show error
        let errMsg = (error.message) ? error.message :
        error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        return Observable.throw(errMsg);
    }
}