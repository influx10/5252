import { Component, OnInit } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";

import { AuthService } from "./auth.service";
import { Router } from "@angular/router";
import { User } from "./user.model";

@Component({
    selector: 'app-signup',
    templateUrl: './signup.component.html'
})
export class SignupComponent implements OnInit {

    /**
     * @type {FormGroup}
     */
    signUpForm: FormGroup;

    formInvalid:Boolean= false;
    formRegistered:Boolean= false;
    emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";

    /**
     * Constructor for SignUpComponent class
     * @param authService
     * @param router
     */
    constructor(private authService: AuthService, private router: Router) {}

    /**
     * @name  onSubmit handle signup
     */
    onSubmit() {
        const user = new User(
            this.signUpForm.value.email,
            this.signUpForm.value.password,
            this.signUpForm.value.userName
        );

        if(this.signUpForm.valid){
            this.authService.signup(user).subscribe(
                    result => console.log(result)
                
                );
            this.formRegistered = true ; 
            this.signUpForm.reset();
        }
        else {
            this.formInvalid = true;
        }
    }

    /**
     * @override OnInit lifecycle method
     */
    ngOnInit() {
        this.signUpForm = new FormGroup({
            //TODO add userName, email and password validators here
            userName: new FormControl('', [Validators.maxLength(20),Validators.minLength(6),Validators.required]),
            email: new FormControl('', [Validators.required,Validators.pattern(this.emailPattern)]),
            password: new FormControl('', [Validators.minLength(6),Validators.required])            
        });
    }
}