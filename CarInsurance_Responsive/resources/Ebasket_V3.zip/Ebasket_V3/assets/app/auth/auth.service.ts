import { Injectable } from "@angular/core";
import { Http, Headers, Response } from "@angular/http";
import 'rxjs/Rx';
import { Observable } from "rxjs";

import { User } from "./user.model";
import { ErrorService } from "../errors/error.service";

/**
 * @name AuthService handle signup, signIn and logout
 */
@Injectable()
export class AuthService {
    /**
     * Constructor for AuthService class
     * @param http
     * @param errorService
     */
    constructor(private http: Http, private errorService: ErrorService) {}

    /**
     * @name: signup handle signup
     * @param user
     * @returns {any|Promise<R>|Promise<T|ErrorObservable>|Promise<ErrorObservable>|Promise<T>}
     */
    signup(user: User) {
        const body = JSON.stringify(user);
        const headers = new Headers({'Content-Type': 'application/json'});
       return this.http.post('http://localhost:3000/user', body, {headers: headers})
       .map(this.extractData)
       .catch(this.handleError);
            //TODO map response here and handle error           
    }

    /**
     * @name signin handle sign in
     * @param user
     * @returns {any|Promise<R>|Promise<T|ErrorObservable>|Promise<ErrorObservable>|Promise<T>}
     */
    signin(user: User) {
        const body = JSON.stringify(user);
        console.log(body);
        const headers = new Headers({'Content-Type': 'application/json'});
        return this.http.post('http://localhost:3000/user/signin', body, {headers: headers})
        .map( response => {
            // login successful if there's a jwt token in the response
            console.log('SELVIN: '+response);
            if (response && response.status === 200 && response.statusText=="OK") {
                let data = response.json();  // If response is a JSON use json()
                //console.log("data", data.token);
                // store user details and jwt token in local storage to keep user logged in between page refreshes
                localStorage.setItem('currentUser', data.token);
            }

            return user;
        })
        .catch(this.handleError);
            //TODO map response here and handle error
    }
    
    private extractData(res: Response) {
        let body = res.json();
        return body || {};
    }
    /**
     * @name logout clear local storage
     */
    logout() {
        //TODO clear local storage
        localStorage.removeItem('currentUser');
    }

    /**
     * @name isLoggedIn check user login
     * @returns {boolean}
     */
    isLoggedIn(): boolean {
        //TODO check is user looged in and return 
        if (localStorage.getItem("currentUser") === null){
            return false;
        }else{
            return true;
        }
    }

    private handleError(error: any) {
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg);
        return Observable.throw(errMsg);
    }
}