$(document).ready(function(){
	
	$("#insurance-main").load("insurance.html",function(){
		
		$("#insuranceCheck").on("change",function(){
			
			$("#firstRow").removeClass("hide");
			
		});
		
		function populateOptions(url, ele){
			
			$.ajax({
				type:'get',
				url:url,
				dataType:'json',
				success: function(data){
					var options='';
					for(var i=0;i<data.data.length;i++){
						options += '<option value="'+data.data[i] +'">' +data.data[i] +'</option>';
					}
					$('#'+ele).append(options);
					
				},
				error: function(data){
					console.log('Error has occured');
				}
			});
			
		}
		
		populateOptions('/CarInsurance_Responsive1/apis/carType.json', 'carName');
		populateOptions('/CarInsurance_Responsive/apis/fuelType.json','carType');
		populateOptions('/CarInsurance_Responsive/apis/registrationState.json','insuranceName');
		
			$('#myForm').on('submit',function(e){
				e.preventDefault();
				
				console.log("testing");
				if(validateform($(this))){
					proceedNext();
				}
				
			});
			
			function validateform(form){
				var counter=0;
				form.find('.form-control').each(function(){
					
					if($(this).val()){
						if($(this).hasClass('uname')){
							if($(this).val().length>=2){
								$(this).parent().removeClass("has-error");
							}else{
								$(this).parent().addClass("has-error");
								counter++;
							}
						}else if($(this).hasClass('pnumber')){
							
							if($(this).val().length==10){
								$(this).parent().removeClass("has-error");
							}else{
								$(this).parent().addClass("has-error");
								counter++;
							}
						}
						else{
							$(this).parent().removeClass('has-error');
						}
						
					}else{
						$(this).parent().addClass("has-error");
						counter++;
					}
					
					
				});
				
				if(counter>0){
					return false;
				}else{
					return true;
				}
				
			}
			
			
			function proceedNext(){
				alert("success");
			}
		
		
	});
	
});