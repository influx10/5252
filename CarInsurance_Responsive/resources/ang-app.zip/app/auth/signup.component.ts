import { Component, OnInit } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";

import { AuthService } from "./auth.service";
import { Router } from "@angular/router";
import { User } from "./user.model";

@Component({
    selector: 'app-signup',
    templateUrl: './signup.component.html'
})
export class SignupComponent implements OnInit {

    /**
     * @type {FormGroup}
     */
    signUpForm: FormGroup;

    formInvalid:Boolean= false;

    /**
     * Constructor for SignUpComponent class
     * @param authService
     * @param router
     */
    constructor(private authService: AuthService, private router: Router) {}

    /**
     * @name  onSubmit handle signup
     */
    onSubmit() {
        const user = new User(
            this.signUpForm.value.email,
            this.signUpForm.value.password,
            this.signUpForm.value.userName
        );

        if(this.signUpForm.valid){
            this.authService.signup(user)
                .subscribe(
                    //TODO handle response and navigate to sign in  and handle error
                    data=>{this.router.navigate(['/','signin']);}
            );
            this.signUpForm.reset();
        }
        else {
            this.formInvalid = true;
        }
    }

    /**
     * @override OnInit lifecycle method
     */
    ngOnInit() {
        this.signUpForm = new FormGroup({
            //TODO add userName, email and password validators here
            userName:new FormControl(null,[Validators.required, Validators.maxLength(20),Validators.minLength(8)]),
            email: new FormControl(null,[Validators.required,Validators.pattern("[a-z0-9!#$%&'*+/=?^_'{|}~-]+(?:\.[a-z0-9!#S%&'*+/=?^`{|}~-]+)@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?")]),
            password:new FormControl(null,[Validators.required,Validators.minLength(6)])
            
        });
    }
}