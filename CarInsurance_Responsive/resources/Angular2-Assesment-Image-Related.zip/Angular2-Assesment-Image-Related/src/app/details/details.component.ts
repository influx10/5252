import { Component, OnInit } from '@angular/core';
import { ServerService } from '../server.service';
import { ActivatedRoute } from '@angular/router';
import { Headers, Http, Response } from '@angular/http';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  details: any;
  invalidForm: boolean = false;

  constructor(private serverService:ServerService, private router:ActivatedRoute, private http:Http) { }

  ngOnInit() {
    this.router.params.subscribe(
      (params) => {
        console.log(params.id);
        
        this.serverService.getImageDetails(params.id).subscribe(
          (response: any) => {
            this.details = response.data;
          }
        );
      }
    );
  }

  onSubmit(f) {
    console.log(f.value);
    if(f.value.imgtype == "") { //imgtype - name of radio
      this.invalidForm = true;
    }
    else {
      this.invalidForm = false;
      console.log(f.value.imgtype);

      //post call with image type (f.value.imgtype) as parameter
      //display success or failure of post call in alert

      //alert("Success: Selected image type is "+f.value.imgtype);
      
      this.details.filter((ele, i) => {       
        if(ele.type == f.value.imgtype){       
          //console.log(this.details[i]);                    
          this.serverService.postDetails(this.details[i]);
          // .subscribe(
          // (response: any) => {
          //   console.log(response.data);
          //   if(!response.data){
          //     alert("Success");
          //   } else {
          //     alert("Failure");
          //   }
          // }
          // );
          return false;
        }
      })
       
    }
  }

}
