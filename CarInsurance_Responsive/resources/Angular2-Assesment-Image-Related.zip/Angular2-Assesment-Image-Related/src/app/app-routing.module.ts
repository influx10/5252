import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CategoriesComponent } from './categories/categories.component';
import { ImagesComponent } from './images/images.component';
import { DetailsComponent } from './details/details.component';

const routes: Routes = [
    { path: '', redirectTo: '/categories', pathMatch: 'full' },
    { path: 'categories', component: CategoriesComponent },
    { path: 'categoryImgages/:id', component: ImagesComponent },
    { path: 'details/:id', component: DetailsComponent }
  ];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [
    RouterModule
   ] 
})
export class AppRoutingModule { };