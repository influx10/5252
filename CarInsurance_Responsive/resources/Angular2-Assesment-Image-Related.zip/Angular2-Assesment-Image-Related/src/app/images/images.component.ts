import { Component, OnInit } from '@angular/core';
import { ServerService } from '../server.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-images',
  templateUrl: './images.component.html',
  styleUrls: ['./images.component.css']
})
export class ImagesComponent implements OnInit {

  categoryImages:any;

  constructor(private serverService:ServerService, private router:Router) { }

  ngOnInit() {
    this.serverService.getCategoryImages().subscribe(
      (response: any) => {
        this.categoryImages = response.data;
      }
    );
  }

  goToDetails(id: number) {
    this.router.navigate(['details', id]); // refer app routing
  }

  getContactDetails(id: number) {
    this.serverService.getContactDetails(id).subscribe(
      (response: any) => {
        var res = response.data[0].name+'\n'+response.data[0].city+'\n'+response.data[0].country;
        alert(res);
      }
    );
  }

}
