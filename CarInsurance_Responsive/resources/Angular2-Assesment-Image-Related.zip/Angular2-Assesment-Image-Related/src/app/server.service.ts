import { Injectable } from '@angular/core';
import { Headers, Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';

@Injectable()
export class ServerService {
  constructor(private http: Http) {}

  getCategories() {
    return this.http.get('assets/categories.json')
      .map(
        (response: Response) => {
          return response.json();
        }
      );
  }

  getCategoryImages() {
    return this.http.get('assets/category-images.json')
      .map(
        (response: Response) => {
          return response.json();
        }
      );
  }
 
  // you will be passing parameter with url - that will be available as comment above the function in exam
  // but not simulated below
  getImageDetails(imageId) {
    return this.http.get('assets/image-details.json')
      .map(
        (response: Response) => {
          return response.json();
        }
      );
  }

  getContactDetails(imageId) {
    return this.http.get('assets/contact-details.json')
      .map(
        (response: Response) => {
          return response.json();
        }
      );
  }

  postDetails(imgObj) { 
    console.log(imgObj);
    alert("Success");
    // return this.http.post('posturl', imgObj)
    // .map(
    //   (response: Response) => {
    //     return response.json();
    //   }
    // );
    return imgObj;   
  }
}
