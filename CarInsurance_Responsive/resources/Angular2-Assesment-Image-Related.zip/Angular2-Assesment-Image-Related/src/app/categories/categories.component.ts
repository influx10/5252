import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServerService } from '../server.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {

  categories:any;

  constructor(private serverService:ServerService, private router:Router) { }

  ngOnInit() {
    this.serverService.getCategories().subscribe(
      (response: any) => {
        this.categories = response.data;
      }
    );
  }

  goToImages(id: number) {
    this.router.navigate(['categoryImgages', id]); // refer app routing
  }

}
