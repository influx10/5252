import { Http, Response, Headers } from "@angular/http";
import { Injectable, EventEmitter } from "@angular/core";
import 'rxjs/Rx';
import { Observable } from "rxjs";
import {Product}  from './product.model';

/**
 * @ProductService
 * @description
 * this service to handle product
 */

@Injectable()
export class ProductService {

    /**
     * @type {string}
     */
    private productsUrl: string = 'data/products.json';

    /**
     * @type {Product[]}
     */
    public products:Product[];

    /**
     * @type {Product[]}
     */
    myBasket: Product[] = [];

    /**
     * @type {string}
     */
    _currntProductType: string = 'fruits';

    /**
     * Constructor for ProductService class
     * @param http
     */
    constructor(private http: Http) {
    }

    /**
     * @param type
     */
    setCurrentProductType(type: string ) {
        this._currntProductType = type;
    }

    /**
     * @returns {string}
     */
    getCurrentProductType(): string {
        return this._currntProductType;
    }

    /**
     * @returns {Product[]}
     */
    public getMyBasket(): Product[]{
        // TODO25
    }


    /**
     * @description add product to basket and update basket details
     * @param product
     */
    addProductToBasket(product: Product){
        //TODO19 add product to basket and update its details
    }

    /**
     *
     * @returns {number} tCount
     */
    getTotalBasketQuantity(): number {
        //TODO20 return total basket quantity
    }

    /**
     * @description reset basket details
     */
    resetBasket() {
        //TODO21 rest basket here

    }

    /**
     * @param product
     */
    setTotalProductBasketPrice(product: Product) {
        product.basketPrice = product.basketCount * product.price;
    }

    /**
     * @returns {number}
     */
    getTotalPrice(): number {
        //TODO22 return total price 
    }

    /**
     * @returns {Observable<Product[]>}
     */
    getProduct(): Observable <Product[]>{
        //TODO23 get products from productUrl
    }

    /**
     * @param res
     * @returns {Product[]}
     */
    private extractProduct(res: Response): Product[] {
        let body = res.json();
        this.products = body.products || { };
        return this.products;
    }

    /**
     * @param error
     * @returns {ErrorObservable}
     */
    private handleError (error: any): Observable<any> {
        //TODO24 handle and show error
    }
}