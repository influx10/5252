import { Http, Response, Headers } from "@angular/http";
import { Injectable, EventEmitter } from "@angular/core";
import 'rxjs/Rx';
import { Observable } from "rxjs";
import {Product}  from './product.model';

/**
 * @ProductService
 * @description
 * this service to handle product
 */

@Injectable()
export class ProductService {

    /**
     * @type {string}
     */
    private productsUrl: string = 'data/products.json';

    /**
     * @type {Product[]}
     */
    public products:Product[];

    /**
     * @type {Product[]}
     */
    myBasket: Product[] = [];

    /**
     * @type {string}
     */
    _currntProductType: string = 'fruits';

    /**
     * Constructor for ProductService class
     * @param http
     */
    constructor(private http: Http) {
    }

    /**
     * @param type
     */
    setCurrentProductType(type: string ) {
        this._currntProductType = type;
    }

    /**
     * @returns {string}
     */
    getCurrentProductType(): string {
        return this._currntProductType;
    }

    /**
     * @returns {Product[]}
     */
    public getMyBasket(): Product[]{
        return this.myBasket;
    }


    /**
     * @description add product to basket and update basket details
     * @param product
     */
    addProductToBasket(product: Product){
        //TODO add product to basket and update its details
    }

    /**
     *
     * @returns {number} tCount
     */
    getTotalBasketQuantity(): number {
        //TODO return total basket quantity
        return 10
    }

    /**
     * @description reset basket details
     */
    resetBasket() {
        //TODO rest basket here

    }

    /**
     * @param product
     */
    setTotalProductBasketPrice(product: Product) {
        product.basketPrice = product.basketCount * product.price;
    }

    /**
     * @returns {number}
     */
    getTotalPrice(): number {
        //TODO return total price 
        return 10
    }

    /**
     * @returns {Observable<Product[]>}
     */
    getProduct(): Observable <Product[]>{
        //TODO get products from productUrl
        return null
    }

    /**
     * @param res
     * @returns {Product[]}
     */
    private extractProduct(res: Response): Product[] {
        let body = res.json();
        this.products = body.products || { };
        return this.products;
    }

    /**
     * @param error
     * @returns {ErrorObservable}
     */
    private handleError (error: any): Observable<any> {
        //TODO handle and show error
        return null
    }
}