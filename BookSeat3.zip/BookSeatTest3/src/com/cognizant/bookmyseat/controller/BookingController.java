package com.cognizant.bookmyseat.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.bookmyseat.ticket.vo.PassengerDetailsVO;
import com.cognizant.bookmyseat.validator.PassengerDetailsValidator;

@Controller
public class BookingController {

	

	// Add appropriate annotations here
	@ModelAttribute("cityList") 
	public Map<String, String> getCities() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("Bengaluru", "Bengaluru");
		map.put("Chennai", "Chennai");
		map.put("Mumbai", "Mumbai");
		return map;
	}

	// Add appropriate annotations here
	@ModelAttribute("genderList")
	public Map<String, String> getGernders() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("Male", "Male");
		map.put("Female", "Female");
		return map;
	}

}
