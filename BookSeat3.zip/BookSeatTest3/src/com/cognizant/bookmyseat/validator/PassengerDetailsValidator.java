package com.cognizant.bookmyseat.validator;

import java.util.Date;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.cognizant.bookmyseat.ticket.vo.PassengerDetailsVO;

public class PassengerDetailsValidator {

	

	
}
